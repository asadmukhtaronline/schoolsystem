<?php

namespace App\Http\Livewire\Admin\Staff;
use App\Models\Staf;
use App\Models\Staffcategory;
use Livewire\WithFileUploads;
use App\Events\OpenUpdateStaff;
use Livewire\Component;

class Allstaff extends Component
{

    
    use WithFileUploads;

    public $name;
    public $description;
    public $cnic;

    public $whatsapp;
    public $gender;
    public $email;
    public $staffcategory_id;

    public function render()
    {
        $staff=staf::all();
        return view('livewire.admin.staff.allstaff',compact('staff'));
    }
    protected $rules = [
        'name' => 'required',
        'whatsapp' => 'required',
        'gender' => 'required',
        'cnic' => 'required',
        'email' => 'required',
        'description' => 'required',
        'staffcategory_id' => 'required'
    ];
   
    
    // save ..
    public function save() {
       // dd("test");
       $this->validate();
        $staff=new staf;
        $staff->name=$this->name;
        $staff->email=$this->email;
        $staff->gender=$this->gender;
        $staff->cnic=$this->cnic;

        $staff->whatsapp=$this->whatsapp;
        $staff->staffcategory_id=$this->staffcategory_id;
        $staff->description=$this->description;
        $staff->save();
        $this->name = " ";
        $this->email = " ";

        $this->whatsapp = " ";
        $this->cnic = " ";

        $this->description = " ";
        $this->email = " ";
        $this->staffcategory_id = " ";
    }
    public function deletestaff($id){
        $staff=staf::find($id);
        $staff->delete();
    }
    public function edit()
    {
        $this->dispatchBrowserEvent('openUpdateStaff');   
    }
}
      