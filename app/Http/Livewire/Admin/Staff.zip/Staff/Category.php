<?php

namespace App\Http\Livewire\Admin\Staff;

use Livewire\Component;
use App\Models\staffcategory;
use Livewire\WithFileUploads;


class Category extends Component
{
    use WithFileUploads;

    public $title;
    public $category_id;
    public $description;
    public $picture;
    public $photo;

    public $updateMode=false;


    public function render()
    {
        $category=staffcategory::all();
        return view('livewire.admin.staff.category',compact('category'));
    }
    protected $rules = [
        'title' => 'required',
        'picture' => 'required',
        'description' => 'required'

    ];
    public function save()
    {
            $this->validate();
            $category=new staffcategory;
            $category->title=$this->title;
            $category->description=$this->description;

            $picture = time().".".$this->picture->getClientOriginalExtension();
            $this->picture->storeAs('staffcategory', $picture,'public');
            $category->picture=$picture;
            $category->save();
            session()->flash('messageadd','category added successfully');
            $this->title = " ";
            $this->picture = " ";

            $this->description = " ";

    }
    public function delete($id)
    {
        $category=staffcategory::find($id);
        session()->flash('messages','category deleted successfully');

        $category->delete();
    }
    public function edit($id)
    {
       
            $this->updateMode=true;
            $category=staffcategory::where('id',$id)->first();
            $this->category_id=$category->id;
            if (!empty($this->picture)){
                $image = time().".".$this->picture->getClientOriginalExtension();
                $this->picture->storeAs('staffcategory', $image,'public');  
                $category->picture=$this->picture;
            }
            $this->title=$category->title;
            $this->description=$category->description;
    }
    public function resetInputFields()
    {
            $this->title =" ";
            $this->description =" ";
            $this->picture=" ";
        

    }
    public function cancel()
    {
        $this->updateMode=false;
        $this->resetInputFields();
    }
    public function update($id)
    {
       
        $category=staffcategory::find($id);
        $category->id = $this->category_id;

        $category->title = $this->title;
        $category->description = $this->description;
       
        if (!empty($this->picture)){
            $picture = time().".".$this->picture->getClientOriginalExtension();
            $this->picture->storeAs('staffcategory', $picture,'public');
            $category->picture=$picture;
        }
        $category->save();
        $this->updateMode=false;
        $this->resetInputFields();
        $this->emit('update');
    }

}

