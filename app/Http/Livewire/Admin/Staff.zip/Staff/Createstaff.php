<?php

namespace App\Http\Livewire\Admin\Staff;

use Livewire\Component;
use App\Models\Staf;
use App\Models\Staffcategory;
// use App\Models\Staffcategory;

use Livewire\WithFileUploads;
class Createstaff extends Component
{
    
    use WithFileUploads;

    public $name;
    public $description;
    public $email;
    public $whatsapp;
    public $gender;
    public $category;
    public $cnic;
    public $photo;

    public function render()
    {
       
        $categories=Staffcategory::all();
        return view('livewire.admin.staff.createstaff',compact('categories'));
        
         
    }
   


    protected $rules = [
        'name' => 'required',
        'description' => 'required',
        'photo' => 'required',
        'whatsapp' => 'required',
        'email' => 'required',
        'gender' => 'required',  
        'category' => 'required',
        'cnic' => 'required',
    ];
    // save ..
    public function save() {
       // dd("test");
       $this->validate();
       $staff=new staf;
       $photoname = time().".".$this->photo->getClientOriginalExtension();
       $this->photo->storeAs('staff',$photoname,'public');
       $staff->image=$photoname;
        $staff->name=$this->name;
        $staff->email=$this->email;
        $staff->cnic=$this->cnic;
        $staff->whatsapp=$this->whatsapp;
        $staff->gender=$this->gender;
        $staff->category=$this->category;
        $staff->description=$this->description;
        $staff->save();
        $this->name = " ";
        $this->email = " ";
        $this->cnic = " ";
        $this->gender = " ";
        $this->whatsapp = " ";
        $this->category = " ";
        $this->description = " ";
        $this->image = "";
        return redirect()->back();    
    }
}
