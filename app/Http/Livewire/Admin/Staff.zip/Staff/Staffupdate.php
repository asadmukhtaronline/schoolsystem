<?php

namespace App\Http\Livewire\Admin\Staff;

use Livewire\Component;
use App\Models\staf;

class Staffupdate extends Component
{
    public $staff;
    public $staff_id;
    public $name;
    public $description;
    public $email;
    public $whatsapp;
    public $gender;
    public $category;
    public $cnic;
    public $photo;


    public function render()
    {
        $staff = $this->staff;
        // $category = $this->categories;
        return view('livewire.admin.staff.staffupdate',compact('staff'));
    }
    
    public function mount($id){
        $this->staff = staf::find($id);
        $this->staff_id=$this->staff->id;

        $this->name = $this->staff->name;
        $this->description = $this->staff->description;
        $this->email = $this->staff->email;
        $this->whatsapp = $this->staff->whatsapp;
        $this->cnic = $this->staff->cnic;
        $this->gender = $this->staff->gender;
    }
    public function resetInputFields()
    {
            $this->name =" ";
            $this->description =" ";
            $this->email =" ";
            $this->whatsapp =" ";
            $this->cnic =" ";
            $this->gender=" ";
    }
    public function update($id)
    {
       
        $staff=staf::find($id);
        $staff->id = $this->staff_id;
        $staff->description = $this->description;
        $staff->name = $this->name;
        $staff->email = $this->email;
        $staff->whatsapp = $this->whatsapp;
        $staff->cnic = $this->cnic;
        $staff->gender = $this->gender;
        $staff->save();
        $this->updateMode=false;
        $this->resetInputFields();
        // $this->emit('update');
    }
}
