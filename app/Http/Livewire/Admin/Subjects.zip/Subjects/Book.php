<?php

namespace App\Http\Livewire\Admin\Subjects;

use Livewire\Component;
use App\Models\Subject;
use Livewire\WithFileUploads;
 
class Book extends Component
{
    use WithFileUploads;

    public $title;
    public $description;
    public $photo;
    public $edittitle;
    public $editdescription;
    public $editphoto;

    public function render()
    {
        $subject = subject::orderby('id','desc')->get();
        return view('livewire.admin.subjects.book',compact('subject'));
    }
    // validation ..
    protected $rules = [
        'title' => 'required',
        'description' => 'required',
        'photo' => 'required'
    ];
    // save ..
    public function save() {
       // dd("test");
       $this->validate();
       $subject=new subject;
       $photoname = time().".".$this->photo->getClientOriginalExtension();
       $this->photo->storeAs('subject',$photoname,'public');
       $subject->image=$photoname;
        $subject->title=$this->title;
        $subject->description=$this->description;
        $subject->save();
        $this->title = " ";
        $this->description = " ";
        $this->photo = null;    
    }
public function deletesubject($id){
    $subject=subject::find($id);
    $subject->delete();
}


// public function editSubject($id) {
//     $subject = subject::find($id);
//     $this->ittle = $subject->title;
//     $this->description = $subject->description;
   

//     // $photoname = time().".".$this->photo->getClientOriginalExtension();
//     // $this->photo->storeAs('subject',$photoname,'public');
//     // $subject->image=$photoname;
//     // $this->editimage=$subject->image;
//     $this->ttitle = " ";
//     $this->description = " ";
//     // $this->photo = null;    

//     $subject->save();
// }
// ------------------------------
// 

        // $this->validate([
        //     'title' => 'required',
        //     'description' => 'required',
        //     'photo' => 'required'

        // ]);

        // $subject = Subject::findOrFail($id);

        // if ($this->photo) {
        //     // If a new photo is uploaded, update the image
        //     $photoname = time() . "." . $this->photo->getClientOriginalExtension();
        //     $this->photo->storeAs('subject', $photoname, 'public');
        //     $subject->image = $photoname;
        // }

        // $subject->title = $this->title;
        // $subject->description = $this->description;
        // $subject->save();

        // // Reset form fields
        // $this->reset(['title', 'description', 'photo']);

        // // Close the modal after updating
        // $this->emit('closeModal');
    }
// }

// public function editSubject($id)
// {
//     $subject = Subject::find($id);
//     $this->editingSubjectId = $id;
//     $this->title = $subject->title;
//     $this->description = $subject->description;
// }

// ----------------------------------------------------------------------------------------------
// Add this method to your Livewire component
// public function editSubject($id) {
//     $this->validate([
//         'title' => 'required',
//         'description' => 'required',
//     ]);

//     $subject = Subject::find($id);

//     if ($this->photo) {
//         // If a new photo is uploaded, update the image
//         $photoname = time() . "." . $this->photo->getClientOriginalExtension();
//         $this->photo->storeAs('subject', $photoname, 'public');
//         $subject->image = $photoname;
//     }

//     $subject->title = $this->title;
//     $subject->description = $this->description;
//     $subject->save();

//     $this->reset(['title', 'description', 'photo']);
// }





