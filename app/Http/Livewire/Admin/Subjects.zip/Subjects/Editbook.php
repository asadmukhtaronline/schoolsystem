<?php

namespace App\Http\Livewire\Admin\Subjects;
use App\Models\Subject;
use Livewire\WithFileUploads;

use Livewire\Component;

class Editbook extends Component
{
    use WithFileUploads;

    public $title;
    public $subject_id;
    public $image;
    public $photo;
    public $photoname;
    

    public $description;
    
    public function render()
    {
        $subjects = $this->subject;
        // $category = $this->categories;
        return view('livewire.admin.subjects.editbook',compact('subjects'));
    }
    public function mount($id){
        $this->subject = subject::find($id);
        $this->subject_id=$this->subject->id;
        $this->title = $this->subject->title;
        $this->description = $this->subject->description;
        if (!empty($this->photo)){
        $photoname = time().".".$this->photo->getClientOriginalExtension();
        $this->photo->storeAs('subject',$photoname,'public');
        $subject->photo=$photoname;
        }
        // $subject->image = $this->image;
        // if (!empty($this->picture)){
        //     $fileimage = time().".".$this->image->getClientOriginalExtension();
        //     $this->image->storeAs('storage/subjects/', $fileimage,'public');
        //     $subject->photo=$this->image;
        // }
        // $this->image=$subject->image;
        
    }
    public function resetInputFields()
    {
            $this->title =" ";
            $this->description =" ";
            $this->image =null;

    }
    public function update($id)
    { 
        $subject=subject::find($id);
        $subject->id = $this->subject_id;
        $subject->title = $this->title;
        $subject->description = $this->description;
        if (!empty($this->photo)){
            $photoname = time().".".$this->photo->getClientOriginalExtension();
            $this->photo->storeAs('subject',$photoname,'public');
            $subject->photo=$photoname;
            }
        // if ($this->photo) {
        //     $photoname = time() . "." . $this->photo->getClientOriginalExtension();
        //     $this->photo->storeAs('subject', $photoname, 'public');
        //     $this->subject->image = $photoname;
        // }
        // $subject->image = $this->image;

        $subject->save();
        // $this->updateMode=false;
        $this->resetInputFields();
        // $this->emit('update');
    }
 
}
